var vetNomes   = ["Paola","Amanda","João Pedro","Eduardo"];
var vetIdades  = [16,15,17,16];
var vetPassou  = [true,false,true,false];

console.log(vetNomes);
console.log(vetIdades);
console.log(vetPassou);
